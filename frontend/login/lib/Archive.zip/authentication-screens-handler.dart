import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:login/authentication-screen.dart';
import 'package:login/background-login.dart';
import 'package:login/sign-up.dart';
import 'package:login/text-input.dart'; // Assuming you save the above code in animated_background_widget.dart
import 'package:login/login.dart';

class AuthenticationScreenHandler extends StatefulWidget {
  LoginPage? loginPage;
  @override
  State<AuthenticationScreenHandler> createState() {
    return _AuthenticationScreenHandlerState();
  }

  AuthenticationScreenHandler({this.loginPage, super.key});
}

class _AuthenticationScreenHandlerState
    extends State<AuthenticationScreenHandler> {
  String bluredLoginBackground = "assets/images/blured-login-background.png";
  String backgroundLogin = "assets/images/login-background.png";
  String? activeBackground;
  @override
  initState() {
    activeBackground = backgroundLogin;
    super.initState();
  }

  void changeScreenToSignUp() {}
  void changeScreemToLogin() {}
  void changeScreenToPrivacyPolicy() {}
  void changeScreenToTermsOfService() {}
  void changeScreenToContinueWithGoogle() {}

  @override
  Widget build(BuildContext context) {
    double? deviceWidth = MediaQuery.of(context).size.width;
    double? deviceHeight = MediaQuery.of(context).size.height;

    //widget activeScreen?;

    return Scaffold(
      body: Stack(
        children: [
          //GEMENI :
          // The animated background
          AnimatedBackgroundWidget(activeBackground: activeBackground!),
          //Image.asset("assets/images/blured-login-background-t.png"),
          //KHODEMOON :
          //SignUpPage(),
          AuthenticationScreen(),
          Column(
            children: [
              SizedBox(height: deviceHeight - 60),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    style: TextButton.styleFrom(
                      splashFactory: NoSplash.splashFactory, // gham :(
                    ),
                    onPressed: () {},
                    child: Text(
                      "privacy policy",
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  Text("|", style: GoogleFonts.poppins(color: Colors.white)),
                  TextButton(
                    style: TextButton.styleFrom(
                      splashFactory: NoSplash.splashFactory,
                    ),
                    onPressed: () {},
                    child: Text(
                      "terms of serive",
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
